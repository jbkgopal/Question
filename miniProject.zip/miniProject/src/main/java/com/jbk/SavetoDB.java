package com.jbk;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class SavetoDB
 */
@WebServlet("/SavetoDB")
public class SavetoDB extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SavetoDB() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Statement statement = DbUtil.giveStatement();
		HttpSession session = request.getSession();
		String graduation = session.getAttribute("graduation").toString();
		String postgraduation = session.getAttribute("postgraduation").toString();
		System.out.println(graduation);
		System.out.println(postgraduation);
		String priskill = session.getAttribute("priskill").toString();
		String secskill = session.getAttribute("secskill").toString();
		System.out.println(priskill);
		System.out.println(secskill);
		request.setAttribute("priskill", priskill);
		request.setAttribute("secskill", secskill);

		String sql = "insert into student (priskill,secskill,graduation,postgraduation) values ('" + graduation + "', '"
				+ postgraduation + "','" + priskill + "','" + secskill + "') ";
		System.out.println(sql);
		int rowsupdated = 0;
		try {
			rowsupdated = statement.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		if (rowsupdated == 1) {
			request.setAttribute("msg", "<font color=\"green\">Data is saved..</font>");
			RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
			rd.forward(request, response);
		} else {
			request.setAttribute("msg", "<font color=\"orange\">Data not saved..</font>");
			RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
			rd.forward(request, response);
		}
	}

}
