package com.jbk;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class PersonalDetailsServlet
 */
@WebServlet("/PersonalDetailsServlet")
public class PersonalDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PersonalDetailsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String priskill = request.getParameter("priskill");
		String secskill = request.getParameter("secskill");
		System.out.println(priskill);
		System.out.println(secskill);
		HttpSession session = request.getSession();
		session.setAttribute("priskill", priskill);
		session.setAttribute("secskill", secskill);
		RequestDispatcher rd = request.getRequestDispatcher("educationdetails.jsp");
		rd.forward(request, response);

		
		
	}

	

}
