package com.JBK.Spring.and.Hibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAndHibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
