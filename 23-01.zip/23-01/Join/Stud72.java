import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name="stud72")
public class Stud72
{
	@Id // it indicates that rno column will be primary key column
	
	int rno; 
	int marks;
	
	public Stud72()
	{
		
	}
	
	
	public Stud72(int rno, int marks) 
	{
		super();
		this.rno = rno;
		this.marks = marks;
	}


	public int getRno() {
		return rno;
	}


	public void setRno(int rno) {
		this.rno = rno;
	}


	public int getMarks() {
		return marks;
	}


	public void setMarks(int marks) {
		//if(marks>0)
			this.marks = marks;
	}

	@Override
	public String toString() {
		return "Student [rno=" + rno + ", marks=" + marks + "]";
	}
	

	
}
