import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="stud71")
public class Stud71
{
	@Id // it indicates that rno column will be primary key column
	int rno; 
	String name;

	public int getRno() {
		return rno;
	}
	
	public void setRno(int rno) {
		this.rno = rno;
	}
	
	public String getName() {
		return name;
	}
	
	@Override
	public String toString() {
		return "StudentInfo [rno=" + rno + ", name=" + name + "]";
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	
}
