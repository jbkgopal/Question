import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HQLJoin {

	public static void main(String[] args) {
		
		Configuration cfg = new Configuration();
		cfg.configure().addAnnotatedClass(Stud71.class).addAnnotatedClass(Stud72.class);    //load load data from hibernate.cfg.xml file into configuration object
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession(); 
		
		Query query =session.createQuery("select s2.rno , s1.name , s2.marks from Stud71 s1 right join Stud72 s2 on s1.rno=s2.rno");
		
		List<Object[]> list=query.list();
		
		for(Object[] o : list)
		{
			System.out.println(o[0] + " " + o[1] + " " + o[2]);
		}

		
		// [     
		// 		[  [1] Integer object  [sachin] String object  [66] Integer object  ]   Object array 1
		// 		[  [2] Integer object  [suresh] String object  [70] Integer object  ]   Object array 2
		// ] 
		
	//			 List<Object[]>
		
		//       List<Student>
		// [ ( ) Student class object () Student class object ] List
		
		
			
//		for(int i=0;i<list.size();i++)
//		{
//			Object[] ob = list.get(i);
//			
//			for(int j=0;j<ob.length;j++)
//				System.out.print(ob[j] + " ");
//			
//			System.out.println();
//			
//		}
//		
		
	}
}
