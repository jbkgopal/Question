

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

public class CriteriaExample3 {

	public static void main(String[] args) {
		
		Session session = new Configuration().configure().addAnnotatedClass(Student.class).buildSessionFactory().openSession();
		
		Criteria criteria=session.createCriteria(Student.class);
			
	//	criteria.add(Restrictions.or(Restrictions.gt("rno",1),Restrictions.gt("marks",90)));
		criteria.add(Restrictions.between("rno", 1, 3));
		
		List<Student> list=criteria.list();
			
// [   [rno=2 marks=70]     [rno=3 marks=50] Student class objects ] List object
		
		System.out.println(list);
		
	}
}
