
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

public class CriteriaExample1 {

	public static void main(String[] args) {
		
		Configuration cfg = new Configuration();
		cfg.configure().addAnnotatedClass(Student.class);    //load load data from hibernate.cfg.xml file into configuration object
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession(); 
		
		/* Criteria API is for retrieving records from database based on some conditions
		 * HQL query is alternative to SQL . HQL insert is not used much. 
		 * Session interface contains bulit in methods for performing general CRUD operations.
		 * */
		
		Criteria criteria=session.createCriteria(Student.class);
		criteria.add(Restrictions.eq("rno",1)); //Retrieve records 
		List<Student> list=criteria.list();
				
		System.out.println(list);
		
	}
}
