

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

public class CriteriaExample2 {

	public static void main(String[] args) {
		
		Session session = new Configuration().configure().addAnnotatedClass(Student.class).buildSessionFactory().openSession();
					
		Criteria criteria=session.createCriteria(Student.class);
				
		criteria.add(Restrictions.in("rno",1,2)); 
		
		List<Student> list=criteria.list();
			
// [   [rno=1 marks=90]     [rno=2 marks=80] Student class objects ] List object
		
		System.out.println(list);
		
	}
}
